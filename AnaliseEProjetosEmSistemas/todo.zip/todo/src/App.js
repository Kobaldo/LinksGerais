
import './App.css';
import TodoList from './componants/TodoList';

function App() {
  return (
   
    <>
    <TodoList/>
    </>
  );
}

export default App;
